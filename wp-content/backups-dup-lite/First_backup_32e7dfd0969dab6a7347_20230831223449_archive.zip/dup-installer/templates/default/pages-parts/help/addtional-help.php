<?php

defined('ABSPATH') || defined('DUPXABSPATH') || exit;

?>
<div id="addtional-help-content">
    For additional help please visit <a href="<?php echo DUPX_Constants::FAQ_URL; ?>" target="_blank">Duplicator Migration and Backup Online Help</a>
</div>
